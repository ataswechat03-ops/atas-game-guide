這 22 張圖片已從 Google Drive《遊戲教學》內嵌圖片整理完成。
請將 drive-image1.webp ～ drive-image22.webp 全部上傳到 GitHub repository：atas-game-guide 的最外層。
網站程式已經接好圖片對應，上傳完成後會自動出現在老虎機、百家樂、骰寶、輪盤、色碟教學內。
